import ConversationView from "./components/ConversationView";

function App() {
  return <ConversationView />;
}

export default App;
